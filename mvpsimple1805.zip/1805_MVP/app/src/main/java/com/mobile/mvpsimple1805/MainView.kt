package com.mobile.mvpsimple1805

interface MainView {
    fun updateLuas(luas : Float)
    fun updateKeliling(keliling : Float)
    fun showError(errorMsg : String)
}